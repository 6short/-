# studentmanager
基于springboot的学生成绩管理系统
## 说明 
端口: 6969  
sql文件在src\main\resources\docs\ssms.sql  
数据库连接配置在src\main\resources\application.yml