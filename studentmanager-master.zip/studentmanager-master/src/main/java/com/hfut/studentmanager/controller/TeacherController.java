package com.hfut.studentmanager.controller;

import com.hfut.studentmanager.pojo.*;
import com.hfut.studentmanager.service.*;
import com.hfut.studentmanager.utils.Message;
import com.hfut.studentmanager.utils.ResultUtils;
import com.hfut.studentmanager.utils.jsonBean.Score;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.lang.System;
import java.util.*;

import static jdk.nashorn.internal.runtime.regexp.joni.Config.log;

@RestController
@RequestMapping("/teacher")
@Slf4j
public class TeacherController {

    @Autowired
    private ClazzCourseTeacherService clazzCourseTeacherService;
    @Autowired
    private ExamService examService;
    @Autowired
    private ClazzService clazzService;
    @Autowired
    private StudentService studentService;
    @Autowired
    private EScoreService eScoreService;
    @Autowired
    private GradeService gradeService;
    @Autowired
    private CourseService courseService;
    @Autowired
    private TeacherService teacherService;
    @Autowired
    private UserService userService;

    @PostMapping("/updatePasswordByTeacher")
    public Message updatePasswordByTeacher(@RequestParam("teacherId") String teacherId,
                                           @RequestParam("oldPassword") String oldPassword,
                                           @RequestParam("newPassword") String newPassword){
        Teacher teacher = teacherService.listTeacherById(Integer.parseInt(teacherId));
        return userService.updatePassword(teacher.getNumber(), oldPassword, newPassword);
    }


    /*
    查看老师信息
     */
    @GetMapping("/listTeacherByNumber")
    public Message listTeacherByNumber(@RequestParam("number") String number){
        Teacher teacher = teacherService.listTeacherByNumber(number);
        return ResultUtils.success(teacher);
    }


    /*
    展示考试信息
     */
    @GetMapping("/listExam")
    public Message listExam(@RequestParam("teacherId") String teacherId){
        //此教师教的所有课程
        List<ClazzCourseTeacher> clazzCourseTeacherList = clazzCourseTeacherService.listClazzCourseTeacherByTeacherId(Integer.parseInt(teacherId));
        List<Map<String, Object>> result = new ArrayList<>();

        for (ClazzCourseTeacher clazzCourseTeacher: clazzCourseTeacherList){
            //课程id
            Integer courseId = clazzCourseTeacher.getCourseId();
            //班级id
            Integer clazzId = clazzCourseTeacher.getClazzId();
            //某门课程发布的考试
            for (Exam exam: examService.listExamByCourseId(courseId)){
                Map<String, Object> map = new HashMap<>();
                if (exam.getType().equals(1)  || exam.getClazzId().equals(clazzId)){
                    map.put("id", exam.getId());
                    map.put("name", exam.getName());
                    map.put("time", exam.getTime());
                    map.put("remark", exam.getRemark());
                    map.put("type", exam.getType());
                    map.put("grade", gradeService.listGradeById(exam.getGradeId()).getName());
                    Clazz clazz = clazzService.listClazzById(exam.getClazzId());
                    if (clazz == null){
                        map.put("clazz", "年级统考");
                    }else {
                        map.put("clazz", clazz.getName());
                    }

                    map.put("course", courseService.listCourseById(exam.getCourseId()).getName());
                    result.add(map);
                }
            }
        }
        return ResultUtils.success(result);
    }

    /*
    成绩录入时选择班级
     */
    @GetMapping("/listClazzByExam")
    public Message listClazzByExam(@RequestParam("examId") String examId){
        Exam exam = examService.listExamById(Integer.parseInt(examId));
        Map<String, Object> result = new HashMap<>();
        List<Clazz> clazzList;
        if (exam.getClazzId() != 0){
            clazzList = new ArrayList<>();
            clazzList.add(clazzService.listClazzById(exam.getClazzId()));
        }else {
            clazzList = clazzService.listClazzByGradeId(exam.getGradeId());
        }
        result.put("clazz", clazzList);
        return ResultUtils.success(result);
    }

    /*
    按照班级展示学生

    @GetMapping("/listStudentByClazz")
    public Message listStudentByClazz(@RequestParam("examId") String examId,
                                      @RequestParam("clazzId") String clazzId){

        List<Student> studentList = studentService.listStudentByClazzandExam(Integer.parseInt(clazzId),Integer.parseInt(examId));
        //List<Student> studentList = studentService.listStudentByClazz(Integer.parseInt(clazzId));

        log.info("examId和clazzId是：{}", examId +" ?"+clazzId);
        if (studentList == null || studentList.size() == 0) {
            return ResultUtils.error(404, "不存在学生");
        }
        List<Map<String, Object>> result = new ArrayList<>();
        for (Student student: studentList){
            Map<String, Object> map = new HashMap<>();
            Escore escore = eScoreService.listEScoreByExamIdAndStudentId(Integer.parseInt(examId), student.getId());
            if (escore != null){
                map.put("score", escore.getScore().toString());
            }else {
                map.put("score", "");
            }
            map.put("studentId", student.getId());
            map.put("number", student.getNumber());
            map.put("name", student.getName());
            map.put("examId", Integer.parseInt(examId));
            result.add(map);
        }
        return ResultUtils.success(result);
    }
     */

    @GetMapping("/listStudentByClazz")
    public Message listStudentByClazz(
            @RequestParam("examId") Integer examId,
            @RequestParam("clazzId") Integer clazzId) {

        // 1️⃣ 查班级所有学生（不管有没有成绩）
        List<Student> studentList = studentService.listStudentByClazz(clazzId);

        if (studentList == null || studentList.isEmpty()) {
            return ResultUtils.success(Collections.emptyList());
        }

        // 2️⃣ 查成绩
        List<Map<String, Object>> result = new ArrayList<>();
        for (Student student : studentList) {
            Map<String, Object> map = new HashMap<>();
            Escore escore = eScoreService
                    .listEScoreByExamIdAndStudentId(examId, student.getId());

            map.put("studentId", student.getId());
            map.put("number", student.getNumber());
            map.put("name", student.getName());
            map.put("examId", examId);
            map.put("score", escore != null ? escore.getScore() : "");

            result.add(map);
        }

        return ResultUtils.success(result);
    }



    /*
    添加成绩
     */
    @PostMapping("/addScore")
    public Message addScore(@RequestBody List<Score> studentScore){
        for (Score score : studentScore) {
            Message result = eScoreService.addEScoreByExamIdAndStudentIdAndCourseId(score.getExamId(), score.getStudentId(),
                    examService.listExamById(score.getExamId()).getCourseId(), Integer.parseInt(score.getScore()));
            if (result.getCode().equals("404")){
                return result;
            }
        }
        return ResultUtils.success();
    }

    /*
   查看教师授课情况111
    */
    @GetMapping("/listTeachingCourses")
    public Message listTeachingCourses(@RequestParam("teacherId") String teacherId){
        // 获取该教师的所有授课记录
        List<ClazzCourseTeacher> clazzCourseTeacherList = clazzCourseTeacherService.listClazzCourseTeacherByTeacherId(Integer.parseInt(teacherId));

        if (clazzCourseTeacherList == null || clazzCourseTeacherList.size() == 0){
            return ResultUtils.error(404, "该教师暂无授课记录");
        }

        List<Map<String, Object>> result = new ArrayList<>();
        for (ClazzCourseTeacher clazzCourseTeacher : clazzCourseTeacherList){
            Map<String, Object> map = new HashMap<>();
            map.put("id", clazzCourseTeacher.getId());

            // 获取年级信息
            Grade grade = gradeService.listGradeById(clazzCourseTeacher.getGradeId());
            if (grade != null){
                map.put("gradeId", grade.getId());
                map.put("gradeName", grade.getName());
            }

            // 获取班级信息
            Clazz clazz = clazzService.listClazzById(clazzCourseTeacher.getClazzId());
            if (clazz != null){
                map.put("clazzId", clazz.getId());
                map.put("clazzName", clazz.getName());
            }

            // 获取课程信息
            Course course = courseService.listCourseById(clazzCourseTeacher.getCourseId());
            if (course != null){
                map.put("courseId", course.getId());
                map.put("courseName", course.getName());
            }

            result.add(map);
        }
        return ResultUtils.success(result);
    }

    /*
    查询成绩
     */
    @GetMapping("/getScore")
    public Message getScore(@RequestParam("examId") String examId,
                            @RequestParam("clazzId") String clazzId){
        List<Map<String, Object>> eScoreList = eScoreService.listESCoreByExamIdAndClazzId(Integer.parseInt(examId), Integer.parseInt(clazzId));
        return ResultUtils.success(eScoreList);
    }
}
