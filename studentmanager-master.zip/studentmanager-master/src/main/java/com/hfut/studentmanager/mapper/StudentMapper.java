package com.hfut.studentmanager.mapper;

import com.hfut.studentmanager.pojo.Student;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface StudentMapper {

    @Insert("insert into student(number, name, sex, phone, qq, clazzId, gradeId) " +
            "values (#{number}, #{name}, #{sex}, #{phone}, #{qq}, #{clazzId}, #{gradeId})")
    boolean insertStudent(Student student);

    @Select("select * from student where id=#{id}")
    Student findStudentById(Integer id);

    @Select("select * from student where number=#{number}")
    Student findStudentByNumber(String number);

    @Select("select * from student where name=#{name}")
    List<Student> findStudentByName(String name);

    @Select("select * from student")
    List<Student> findAllStudent();

    @Select("select * from student where clazzId=#{clazzId}")
    List<Student> findStudentByClazzId(Integer clazzId);

    @Select("select * from student,exam where student.clazzId=#{clazzId} and student.gradeId=exam.gradeId"+" and exam.id=#{examId}")
    List<Student> findStudentByClazzandExam(@Param("clazzId") Integer clazzId, @Param("examId") Integer examId);

    @Select("select * from student where gradeId=#{gradeId}")
    List<Student> findStudentByGradeId(Integer gradeId);


    void updateStudent(Student student);

    @Delete("delete from student where id=#{id}")
    boolean deleteStudentById(Integer id);

}
