package com.hfut.studentmanager.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TeacherDTO {
    private Integer id;
    private String number;//工号
    private String name;//姓名
    private String sex;//性别
    private String phone;
    private String qq;
}
