package com.hfut.studentmanager.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class StudentDTO {
        private Integer id;
        private String number;//学号
        private String name;//姓名
        private String sex;//性别
        private String phone;
        private String qq;
        //private String clazzId;//注意外键
        //private String gradeId;
}
