package com.hfut.studentmanager.service;

import com.hfut.studentmanager.mapper.StudentMapper;
import com.hfut.studentmanager.mapper.TeacherMapper;
import com.hfut.studentmanager.mapper.UserMapper;
import com.hfut.studentmanager.pojo.Student;
import com.hfut.studentmanager.pojo.Teacher;
import com.hfut.studentmanager.pojo.User;
import com.hfut.studentmanager.utils.Message;
import com.hfut.studentmanager.utils.ResultUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

@Service
public class UserService {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private TeacherMapper teacherMapper;

    @Autowired
    private StudentMapper studentMapper;

    public User login(String account, String password){
        User user = userMapper.findUserByAccount(account);
        if (user == null || !password.equals(user.getPassword())){
            return null;
        }
        return user;
    }

    User findByAccount (String account){
        return userMapper.findUserByAccount(account);
    };

    @Transactional
    public Message register(User user,
                            Integer clazzId,
                            Integer gradeId,
                            String sex,
                            String phone,
                            String qq) {

        // 1. 账号是否存在
        if (userMapper.findUserByAccount(user.getAccount()) != null) {
            return ResultUtils.error(404, "用户已存在");
        }

        // 2. 插入 user 表
        if (!userMapper.insertUser(user)) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            return ResultUtils.error(404, "注册失败");
        }

        // 3. 根据类型插入 student / teacher
        if (user.getType() == 2) { // 学生
            Student student = new Student();
            student.setNumber(user.getAccount());
            student.setName(user.getName());
            student.setSex(sex);
            student.setPhone(phone);
            student.setQq(qq);
            student.setClazzId(clazzId);
            student.setGradeId(gradeId);

            if (!studentMapper.insertStudent(student)) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                return ResultUtils.error(404, "学生信息创建失败");
            }
        }

        if (user.getType() == 3) { // 老师
            Teacher teacher = new Teacher();
            teacher.setNumber(user.getAccount());
            teacher.setName(user.getName());
            teacher.setSex(sex);
            teacher.setPhone(phone);
            teacher.setQq(qq);

            if (!teacherMapper.insertTeacher(teacher)) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                return ResultUtils.error(404, "教师信息创建失败");
            }
        }

        return ResultUtils.success("注册成功");
    }


    @Transactional
    public Message addUser(User user){
        if (userMapper.findUserByAccount(user.getAccount()) != null){
            return ResultUtils.error(404, "用户已存在");
        }
        if (!userMapper.insertUser(user)){
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            return ResultUtils.error(404, "用户注册失败");
        }
        return ResultUtils.success("注册成功");
    }

    @Transactional
    public Message updatePassword(String account, String oldPassword, String newPassword){
        User user = userMapper.findUserByAccount(account);
        if (user == null){
            return ResultUtils.error(404, "用户不存在");
        }
        if (!user.getPassword().equals(oldPassword)){
            return ResultUtils.error(404, "密码错误");
        }
        user.setPassword(newPassword);
        if (!userMapper.updateUserPassword(user)){
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            return ResultUtils.error(404, "密码修改失败");
        }
        return ResultUtils.success();
    }
}
