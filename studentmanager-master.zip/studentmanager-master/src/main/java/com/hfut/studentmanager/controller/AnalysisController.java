package com.hfut.studentmanager.controller;


import com.hfut.studentmanager.pojo.Clazz;
import com.hfut.studentmanager.pojo.Course;
import com.hfut.studentmanager.pojo.Escore;
import com.hfut.studentmanager.pojo.Exam;
import com.hfut.studentmanager.pojo.Grade;
import com.hfut.studentmanager.pojo.Student;
import com.hfut.studentmanager.service.ClazzCourseTeacherService;
import com.hfut.studentmanager.service.ClazzService;
import com.hfut.studentmanager.service.CourseService;
import com.hfut.studentmanager.service.EScoreService;
import com.hfut.studentmanager.service.ExamService;
import com.hfut.studentmanager.service.GradeService;
import com.hfut.studentmanager.service.StudentService;
import com.hfut.studentmanager.utils.Message;
import com.hfut.studentmanager.utils.ResultUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;

@RestController
@RequestMapping("/analysis")
@Slf4j
public class AnalysisController {

    @Autowired
    private EScoreService eScoreService;
    @Autowired
    private ExamService examService;
    @Autowired
    private StudentService studentService;
    @Autowired
    private CourseService courseService;
    @Autowired
    private GradeService gradeService;
    @Autowired
    private ClazzService clazzService;
    @Autowired
    private ClazzCourseTeacherService clazzCourseTeacherService;

    /**
     * 教师端：获取某次考试、某个班级的统计数据（平均分/最低分/最高分/及格率、学生排名）
     */
    @GetMapping("/teacher/examClazzStats")
    public Message examClazzStats(@RequestParam("examId") Integer examId,
                                  @RequestParam("clazzId") Integer clazzId,
                                  @RequestParam("teacherId") Integer teacherId){
        Exam exam = examService.listExamById(examId);
        if (exam == null){
            return ResultUtils.error(404, "考试不存在");
        }
        // 鉴权：老师必须授课该班级的该课程
        if (!clazzCourseTeacherService.teacherOwnsCourse(exam.getGradeId(), clazzId, exam.getCourseId(), teacherId)){
            return ResultUtils.error(403, "无权限查看该班级本次考试数据");
        }

        List<Escore> scores = eScoreService.listByExamIdAndClazzId(examId, clazzId);
        if (scores == null || scores.isEmpty()){
            return ResultUtils.success(Collections.emptyMap());
        }

        int total = scores.size();
        int passCount = 0;
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        int sum = 0;
        List<Map<String, Object>> ranking = new ArrayList<>();
        for (Escore escore : scores){
            Integer sc = escore.getScore();
            sum += sc;
            min = Math.min(min, sc);
            max = Math.max(max, sc);
            if (sc >= 60){
                passCount++;
            }
            Student stu = studentService.listStudentById(escore.getStudentId());
            Map<String, Object> item = new HashMap<>();
            item.put("studentId", escore.getStudentId());
            item.put("number", stu != null ? stu.getNumber() : "");
            item.put("name", stu != null ? stu.getName() : "");
            item.put("score", sc);
            ranking.add(item);
        }
        ranking.sort((a, b) -> ((Integer)b.get("score")).compareTo((Integer)a.get("score")));
        for (int i = 0; i < ranking.size(); i++){
            ranking.get(i).put("rank", i + 1);
        }

        double avg = total == 0 ? 0 : (sum * 1.0 / total);
        double passRate = total == 0 ? 0 : (passCount * 100.0 / total);

        Clazz clazz = clazzService.listClazzById(clazzId);
        Grade grade = gradeService.listGradeById(exam.getGradeId());
        Course course = courseService.listCourseById(exam.getCourseId());

        Map<String, Object> result = new HashMap<>();
        result.put("examId", exam.getId());
        result.put("examName", exam.getName());
        result.put("courseId", exam.getCourseId());
        result.put("courseName", course != null ? course.getName() : "");
        result.put("gradeId", exam.getGradeId());
        result.put("gradeName", grade != null ? grade.getName() : "");
        result.put("clazzId", clazzId);
        result.put("clazzName", clazz != null ? clazz.getName() : "");
        result.put("avgScore", avg);
        result.put("minScore", min);
        result.put("maxScore", max);
        result.put("passRate", passRate);
        result.put("passCount", passCount);
        result.put("total", total);
        result.put("ranking", ranking);
        return ResultUtils.success(result);
    }

    /**
     * 学生端：成绩趋势（按考试时间顺序）
     */
    @GetMapping("/student/examTrend")
    public Message examTrend(@RequestParam("studentId") Integer studentId,
                             @RequestParam(value = "courseId", required = false) Integer courseId){
        Student student = studentService.listStudentById(studentId);
        if (student == null){
            return ResultUtils.error(404, "学生不存在");
        }
        List<Escore> scores = eScoreService.listByStudentId(studentId);
        if (scores == null){
            scores = new ArrayList<>();
        }
        List<Map<String, Object>> list = new ArrayList<>();
        for (Escore escore : scores){
            if (courseId != null && !courseId.equals(escore.getCourseId())){
                continue;
            }
            Exam exam = examService.listExamById(escore.getExamId());
            if (exam == null){
                continue;
            }
            Course course = courseService.listCourseById(escore.getCourseId());
            Map<String, Object> item = new HashMap<>();
            item.put("examId", escore.getExamId());
            item.put("examName", exam.getName());
            item.put("time", exam.getTime());
            item.put("courseId", escore.getCourseId());
            item.put("courseName", course != null ? course.getName() : "");
            item.put("score", escore.getScore());
            list.add(item);
        }
        list.sort((a, b) -> {
            Date ta = (Date) a.get("time");
            Date tb = (Date) b.get("time");
            if (ta == null && tb == null) return 0;
            if (ta == null) return -1;
            if (tb == null) return 1;
            return ta.compareTo(tb);
        });
        return ResultUtils.success(list);
    }

    /**
     * 学生端：同时间/同年级/同类型（统考或班级）下，不同科目成绩柱状图数据
     * 参数：studentId, gradeId, examDate(yyyy-MM-dd), type(1统考/2班级), 可选courseId
     */
    @GetMapping("/student/subjectBar")
    public Message subjectBar(@RequestParam("studentId") Integer studentId,
                              @RequestParam("gradeId") Integer gradeId,
                              @RequestParam("examDate") String examDate,
                              @RequestParam("type") Integer type,
                              @RequestParam(value = "courseId", required = false) Integer courseId){
        Student student = studentService.listStudentById(studentId);
        if (student == null){
            return ResultUtils.error(404, "学生不存在");
        }
        List<Escore> scores = eScoreService.listByStudentId(studentId);
        if (scores == null){
            scores = new ArrayList<>();
        }


        LocalDate reqDate = LocalDate.parse(examDate);
        List<Map<String, Object>> list = new ArrayList<>();
        for (Escore escore : scores){
            Exam exam = examService.listExamById(escore.getExamId());
            if (exam == null){
                continue;
            }

            // 同年级
            if (!gradeId.equals(exam.getGradeId())){
                continue;
            }

            // 同类型
            if (!type.equals(exam.getType())){
                continue;
            }

            // 同日期（修复时区问题）
            if (exam.getTime() == null){
                continue;
            }

            LocalDate examDateLocal = exam.getTime()
                    .toInstant()
                    .atZone(ZoneId.of("Asia/Shanghai"))
                    .toLocalDate();

            if (!examDateLocal.equals(reqDate)){
                continue;
            }

            // 同科目（可选）
            if (courseId != null && !courseId.equals(exam.getCourseId())){
                continue;
            }

            Course course = courseService.listCourseById(exam.getCourseId());
            Map<String, Object> item = new HashMap<>();
            item.put("examId", exam.getId());
            item.put("examName", exam.getName());
            item.put("courseId", exam.getCourseId());
            item.put("courseName", course != null ? course.getName() : "");
            item.put("score", escore.getScore());
            list.add(item);
        }

        return ResultUtils.success(list);
    }
}
