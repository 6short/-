package com.hfut.studentmanager.controller;

import com.hfut.studentmanager.pojo.User;
import com.hfut.studentmanager.service.UserService;
import com.hfut.studentmanager.utils.Message;
import com.hfut.studentmanager.utils.ResultUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class LoginController {

    @Autowired
    UserService userService;

    @RequestMapping("/")
    public String hello(){
        return "你好，访问成功";
    }

    @PostMapping("/login")
    public Message login(
            @RequestParam("account") String account,
            @RequestParam("password") String password
    ){
        User user = userService.login(account, password);
        if (user == null){
            return ResultUtils.error(404, "登录失败");
        }
        return ResultUtils.loginSuccess(user);
    }

    @PostMapping("/register")
    public Message register(
            @RequestParam String account,
            @RequestParam String password,
            @RequestParam String name,
            @RequestParam Integer type,
            @RequestParam(required = false) Integer clazzId,
            @RequestParam(required = false) Integer gradeId,
            @RequestParam(required = false) String sex,
            @RequestParam(required = false) String phone,
            @RequestParam(required = false) String qq
    ) {
        User user = new User();
        user.setAccount(account);
        user.setPassword(password);
        user.setName(name);
        user.setType(type);

        return userService.register(user, clazzId, gradeId, sex, phone, qq);
    }



}
