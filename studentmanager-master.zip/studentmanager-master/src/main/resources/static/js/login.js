/*import { saveUser, setStatus } from "./common.js";

const form = document.getElementById("loginForm");
const statusEl = document.getElementById("loginStatus");
const roleSelect = document.getElementById("role");

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  setStatus(statusEl, "");
  const account = document.getElementById("account").value.trim();
  const password = document.getElementById("password").value.trim();
  const role = roleSelect.value;
  if (!account || !password) {
    setStatus(statusEl, "请输入账号和密码");
    return;
  }
  try {
    const res = await fetch("/login", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ account, password }),
    });
    const data = await res.json();
    if (!data || data.code !== "200") {
      setStatus(statusEl, data ? data.msg : "登录失败");
      return;
    }
    const user = data.data;
    const targetType = parseInt(role, 10);
    if (user.type !== targetType) {
      setStatus(statusEl, "选择的身份与账号类型不一致");
      return;
    }
    saveUser(user);
    const target =
      user.type === 1
        ? "system.html"
        : user.type === 2
        ? "student.html"
        : "teacher.html";
    window.location.href = target;
  } catch (err) {
    setStatus(statusEl, err.message || "登录失败");
  }
});

 */

import { saveUser, setStatus } from "./common.js";

const form = document.getElementById("loginForm");
const statusEl = document.getElementById("loginStatus");
const roleSelect = document.getElementById("role");
const loginBtn = document.getElementById("loginBtn");

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  setStatus(statusEl, "");
  loginBtn.disabled = true;

  try {
    const account = document.getElementById("account").value.trim();
    const password = document.getElementById("password").value.trim();
    const role = roleSelect.value;

    if (!account || !password) {
      setStatus(statusEl, "请输入账号和密码");
      loginBtn.disabled = false;
      return;
    }

    // 以 application/x-www-form-urlencoded 方式发送（与后端 @RequestParam 兼容）
    const body = new URLSearchParams({ account, password });

    const res = await fetch("/login", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: body.toString(),
    });

    // 如果后端返回非 JSON 或状态非 200 也能友好提示
    let data;
    try {
      data = await res.json();
    } catch (err) {
      throw new Error(`服务器返回非 JSON 响应，状态 ${res.status}`);
    }

    if (!data || data.code !== "200") {
      setStatus(statusEl, data ? data.msg || "登录失败" : "登录失败");
      loginBtn.disabled = false;
      return;
    }

    const user = data.data;
    const targetType = parseInt(role, 10);

    if (user.type !== targetType) {
      setStatus(statusEl, "选择的身份与账号类型不一致");
      loginBtn.disabled = false;
      return;
    }

    // 记住我处理（可选）：如果勾选则长期保存
    const remember = document.getElementById("remember").checked;
    saveUser(user, remember);

    const target =
        user.type === 1 ? "system.html" : user.type === 2 ? "student.html" : "teacher.html";

    window.location.href = target;
  } catch (err) {
    setStatus(statusEl, err.message || "登录失败");
    loginBtn.disabled = false;
  }
});


