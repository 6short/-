import {
  ensureUser,
  fetchJSON,
  postForm,
  renderTable,
  renderList,
  formatDate,
  setStatus,
  bindLogout,
} from "./common.js";

let allGrades = [];
let allCourses = [];
let allClazzes = [];

const user = ensureUser([3]);
let teachingCourses = [];
let allExams = [];
if (user) {
  init();
}

async function init() {
  bindLogout("logoutBtn");
  document.getElementById("welcomeName").textContent = user.name;
  document.getElementById("welcomeAccount").textContent = user.account;
  await loadTeacherInfo();
  await loadAllExams();
  bindStatsForm();
  bindPasswordForm();
  bindScoreEntry();
}

async function loadTeacherInfo() {
  const profileBox = document.getElementById("profileBox");
  try {
    const info = await fetchJSON(
      `/teacher/listTeacherByNumber?number=${encodeURIComponent(
        user.account
      )}`
    );
    if (!info) throw new Error("未找到教师信息");
    document.getElementById("teacherId").value = info.id;
    profileBox.innerHTML = `
      <div class="grid grid-2">
        <div><div class="section-title">姓名</div><div>${info.name}</div></div>
        <div><div class="section-title">工号</div><div>${info.number}</div></div>
        <div><div class="section-title">电话</div><div>${info.phone || "-"}</div></div>
        <div><div class="section-title">QQ</div><div>${info.qq || "-"}</div></div>
      </div>
    `;
    await loadTeachingCourses(info.id);
    await loadExams(info.id);
    refreshGradeOptions();
  } catch (err) {
    profileBox.innerHTML = `<p class="error">${err.message}</p>`;
  }
}

async function loadTeachingCourses(teacherId) {
  const container = document.getElementById("courseBox");
  const list = await fetchJSON(
    `/teacher/listTeachingCourses?teacherId=${teacherId}`
  );
  teachingCourses = list || [];
  renderList(
    teachingCourses,
    container,
    (item) =>
      `${item.gradeName || "-"} / ${item.clazzName || "-"} - ${item.courseName}`
  );
}

document.addEventListener("DOMContentLoaded", async () => {
  await loadAllGrades();
  await loadAllCourses();
  await loadAllClazzes();
  await loadAllExams();   // ⬅️ 必须在绑定事件前
  bindStatsForm();
});


async function loadExams(teacherId) {
  const box = document.getElementById("examBox");
  const rows = await fetchJSON(`/teacher/listExam?teacherId=${teacherId}`);
  renderTable(
    (rows || []).map((x) => ({
      id: x.id,
      name: x.name,
      time: formatDate(x.time),
      type: x.type === 1 ? "统考" : "班级",
      grade: x.grade,
      clazz: x.clazz,
      course: x.course,
    })),
    [
      { title: "ID", dataIndex: "id" },
      { title: "考试", dataIndex: "name" },
      { title: "日期", dataIndex: "time" },
      { title: "类型", dataIndex: "type" },
      { title: "年级/班级", dataIndex: "clazz" },
      { title: "科目", dataIndex: "course" },
    ],
    box
  );
}

function bindStatsForm() {
  const form = document.getElementById("statsForm");
  const statusEl = document.getElementById("statsStatus");
  const gradeSelect = document.getElementById("statsGrade");
  const courseSelect = document.getElementById("statsCourse");
  const clazzSelect = document.getElementById("statsClazzId");

  gradeSelect.addEventListener("change", () => {
    refreshCourseOptions(gradeSelect.value);
    refreshClazzOptions(gradeSelect.value, "");
    refreshExamOptions(gradeSelect.value, "");
  });

  courseSelect.addEventListener("change", () => {
    refreshClazzOptions(gradeSelect.value, courseSelect.value);
    refreshExamOptions(gradeSelect.value, courseSelect.value);
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    setStatus(statusEl, "");

    const gradeId = gradeSelect.value;
    const courseId = courseSelect.value;
    const examId = document.getElementById("statsExamId").value;
    const clazzId = clazzSelect.value;
    const teacherId = document.getElementById("teacherId").value;

    if (!gradeId || !courseId || !examId || !clazzId) {
      setStatus(statusEl, "请选择年级、课程、考试和班级");
      return;
    }

    const url = new URL(
        `/analysis/teacher/examClazzStats`,
        window.location.origin
    );
    url.searchParams.set("examId", examId);
    url.searchParams.set("clazzId", clazzId);
    url.searchParams.set("teacherId", teacherId);

    try {
      const data = await fetchJSON(url.toString());
      renderStatsResult(data);
      setStatus(statusEl, "加载成功", "success");
    } catch (err) {
      setStatus(statusEl, err.message);
    }
  });
}

function renderStatsResult(data) {
  const metaBox = document.getElementById("statsMeta");
  metaBox.innerHTML = `
    <div class="grid grid-2">
      <div><div class="section-title">考试</div><div>${data.examName}</div></div>
      <div><div class="section-title">科目</div><div>${data.courseName}</div></div>
      <div><div class="section-title">班级</div><div>${data.clazzName}</div></div>
      <div><div class="section-title">平均分</div><div>${data.avgScore}</div></div>
      <div><div class="section-title">最高分</div><div>${data.maxScore}</div></div>
      <div><div class="section-title">最低分</div><div>${data.minScore}</div></div>
      <div><div class="section-title">及格率</div><div>${(data.passRate || 0).toFixed(1)}%</div></div>
      <div><div class="section-title">人数</div><div>${data.total}</div></div>
    </div>
  `;

  renderTable(
      data.ranking || [],
      [
        { title: "名次", dataIndex: "rank" },
        { title: "姓名", dataIndex: "name" },
        { title: "学号", dataIndex: "number" },
        { title: "成绩", dataIndex: "score" },
      ],
      document.getElementById("statsRanking")
  );
}


function populateSelect(selectEl, list, placeholder, valueKey = "id", labelKey = "name") {
  if (!selectEl) return;
  const options = [`<option value="">${placeholder}</option>`];
  (list || []).forEach((item) => {
    options.push(
      `<option value="${item?.[valueKey] ?? ""}">${item?.[labelKey] ?? ""}</option>`
    );
  });
  selectEl.innerHTML = options.join("");
}

function refreshGradeOptions() {
  const gradeSelect = document.getElementById("statsGrade");
  const gradeMap = new Map();
  (teachingCourses || []).forEach((item) => {
    if (item.gradeId) {
      gradeMap.set(item.gradeId, item.gradeName || item.gradeId);
    }
  });
  const gradeList = Array.from(gradeMap.entries()).map(([id, name]) => ({
    id,
    name,
  }));
  populateSelect(gradeSelect, gradeList, "选择年级");
  refreshCourseOptions(gradeSelect.value);
}

function refreshCourseOptions(gradeId) {
  const courseSelect = document.getElementById("statsCourse");
  if (!gradeId) {
    populateSelect(courseSelect, [], "选择课程");
    refreshClazzOptions("", "");
    return;
  }
  const courseMap = new Map();
  (teachingCourses || [])
    .filter((item) => String(item.gradeId) === String(gradeId))
    .forEach((item) => {
      if (item.courseId) {
        courseMap.set(item.courseId, item.courseName || item.courseId);
      }
    });
  const courseList = Array.from(courseMap.entries()).map(([id, name]) => ({
    id,
    name,
  }));
  populateSelect(courseSelect, courseList, "选择课程");
  refreshClazzOptions(gradeId, courseSelect.value);
}

function refreshClazzOptions(gradeId, courseId) {
  const clazzSelect = document.getElementById("statsClazzId");
  if (!gradeId || !courseId) {
    populateSelect(clazzSelect, [], "选择班级");
    refreshExamOptions("", "", "");
    return;
  }
  const clazzMap = new Map();
  (teachingCourses || [])
    .filter(
      (item) =>
        String(item.gradeId) === String(gradeId) &&
        String(item.courseId) === String(courseId)
    )
    .forEach((item) => {
      if (item.clazzId) {
        clazzMap.set(item.clazzId, item.clazzName || item.clazzId);
      }
    });
  const clazzList = Array.from(clazzMap.entries()).map(([id, name]) => ({
    id,
    name,
  }));
  populateSelect(clazzSelect, clazzList, "选择班级");
  refreshExamOptions(gradeId, courseId, clazzSelect.value);
}


async function loadAllExams() {
  try {
    const res = await fetchJSON("/system/list?method=listAllExam");
    allExams = Array.isArray(res) ? res : [];
    console.log("✅ allExams 加载完成：", allExams);
  } catch (e) {
    console.error("❌ 加载考试失败", e);
    allExams = [];
  }
}


function refreshExamOptions(gradeId, courseId) {
  const examSelect = document.getElementById("statsExamId");
  if (!examSelect) return;

  if (!gradeId || !courseId) {
    populateSelect(examSelect, [], "选择年级和课程");
    return;
  }

  // 用 teachingCourses 反查名字
  const gradeName = teachingCourses.find(
      t => String(t.gradeId) === String(gradeId)
  )?.gradeName;

  const courseName = teachingCourses.find(
      t =>
          String(t.gradeId) === String(gradeId) &&
          String(t.courseId) === String(courseId)
  )?.courseName;

  console.log("🎯 当前筛选条件:", gradeName, courseName);

  const filtered = (allExams || []).filter(e =>
      e.grade === gradeName && e.course === courseName
  );

  console.log("🎯 匹配到的考试:", filtered);

  populateSelect(
      examSelect,
      filtered.map(e => ({ id: e.id, name: e.name })),
      filtered.length ? "选择考试" : "该课程暂无考试"
  );
}


function bindPasswordForm() {
  const form = document.getElementById("passwordForm");
  const statusEl = document.getElementById("passwordStatus");
  if (!form) return;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    setStatus(statusEl, "");
    const oldPassword = document.getElementById("oldPassword").value.trim();
    const newPassword = document.getElementById("newPassword").value.trim();
    const confirmPassword = document
      .getElementById("confirmPassword")
      .value.trim();
    const teacherId = document.getElementById("teacherId").value;
    if (!oldPassword || !newPassword) {
      setStatus(statusEl, "请输入原密码和新密码");
      return;
    }
    if (newPassword !== confirmPassword) {
      setStatus(statusEl, "两次输入的新密码不一致");
      return;
    }
    try {
      await postForm("/teacher/updatePasswordByTeacher", {
        teacherId,
        oldPassword,
        newPassword,
      });
      form.reset();
      setStatus(statusEl, "密码修改成功", "success");
    } catch (err) {
      setStatus(statusEl, err.message || "修改失败");
    }
  });
}

function bindScoreEntry() {
  const examSelect = document.getElementById("scoreExamSelect");
  const clazzSelect = document.getElementById("scoreClazzSelect");
  const loadBtn = document.getElementById("loadStudentsBtn");
  const saveBtn = document.getElementById("saveScoresBtn");

  // 1️⃣ 加载考试
  populateSelect(examSelect, allExams, "选择考试");

  // 2️⃣ 选考试 → 加载班级
  examSelect.addEventListener("change", async () => {
    const examId = examSelect.value;
    if (!examId) {
      populateSelect(clazzSelect, [], "选择班级");
      return;
    }
    const res = await fetchJSON(
        `/teacher/listClazzByExam?examId=${examId}`
    );
    populateSelect(clazzSelect, res.clazz || [], "选择班级");
  });

  // 3️⃣ 加载学生
  loadBtn.addEventListener("click", async () => {
    const examId = examSelect.value;
    const clazzId = clazzSelect.value;

    if (!examId || !clazzId) {
      setStatus(scoreStatus, "请选择考试和班级");
      return;
    }

    const list = await fetchJSON(
        `/teacher/listStudentByClazz?examId=${examId}&clazzId=${clazzId}`
    );
    renderScoreTable(list);
  });

  // 4️⃣ 保存成绩
  saveBtn.addEventListener("click", async () => {
    const examId = examSelect.value;
    const inputs = document.querySelectorAll(".score-input");

    const payload = [];
    inputs.forEach((i) => {
      if (i.value !== "") {
        payload.push({
          examId,
          studentId: i.dataset.studentId,
          score: i.value,
        });
      }
    });

    await fetch("/teacher/addScore", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    setStatus(saveScoresStatus, "保存成功", "success");
  });
}

function renderScoreTable(list) {
  const html = `
    <table class="table">
      <tr>
        <th>学号</th>
        <th>姓名</th>
        <th>成绩</th>
      </tr>
      ${list
      .map(
          (s) => `
          <tr>
            <td>${s.number}</td>
            <td>${s.name}</td>
            <td>
              <input type="number"
                     min="0" max="100"
                     value="${s.score ?? ""}"
                     data-student-id="${s.studentId}"
                     class="score-input"/>
            </td>
          </tr>`
      )
      .join("")}
    </table>
  `;
  document.getElementById("scoreTable").innerHTML = html;
}


