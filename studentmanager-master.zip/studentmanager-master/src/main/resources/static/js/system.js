import {
  ensureUser,
  fetchJSON,
  postForm,
  renderTable,
  renderList,
  formatDate,
  setStatus,
  bindLogout,
} from "./common.js";

const user = ensureUser([1]);
if (user) {
  init();
}

async function init() {
  bindLogout("logoutBtn");
  document.getElementById("welcomeName").textContent = user.name;
  document.getElementById("welcomeAccount").textContent = user.account;

  await loadAllBaseData();
  await loadBasicLists();
  bindForms();
  bindStudentGradeChange();

  bindUpdateFormsAndSelects();
}

function bindStudentGradeChange() {
  const gradeSelect = document.getElementById("studentGradeSelect");
  const clazzSelect = document.getElementById("studentClazzSelect");

  if (!gradeSelect || !clazzSelect) return;

  gradeSelect.addEventListener("change", () => {
    const gradeId = gradeSelect.value;
    const filteredClazz =
        allClazzes.filter((c) => String(c.gradeId) === String(gradeId)) || [];
    populateSelect(clazzSelect, filteredClazz, "选择班级");
  });
}


async function loadBasicLists() {
  await Promise.all([loadList("grade"), loadList("clazz"),
    loadList("course"),loadList("teacher"),
    loadList("student"),
    loadList("exam")]);
}

function populateSelect(selectEl, list, placeholder) {
  if (!selectEl) return;
  selectEl.innerHTML =
      `<option value="">${placeholder}</option>` +
      (list || [])
          .map((item) => `<option value="${item.id}">${item.name}</option>`)
          .join("");
}

let allGrades = [];
let allCourses = [];
let allClazzes = [];
let allTeachers = [];
let allStudents = [];
/*
async function loadAllBaseData() {
  allGrades = await fetchJSON("/system/list?method=listAllGrade") || [];
  allCourses = await fetchJSON("/system/list?method=listAllCourse") || [];
  allClazzes = await fetchJSON("/system/list?method=listAllClazz") || [];

  // 填充考试管理下拉框
  populateSelect(document.getElementById("examGradeSelect"), allGrades, "选择年级");
  populateSelect(document.getElementById("examCourseSelect"), allCourses, "选择课程");
  populateSelect(document.getElementById("examClazzSelect"), [], "选择班级");

  // ✅ 绑定班级联动事件
  const examGradeSelect = document.getElementById("examGradeSelect");
  const examClazzSelect = document.getElementById("examClazzSelect");
  console.log(allClazzes[0]);

  if (examGradeSelect && examClazzSelect) {
    examGradeSelect.addEventListener("change", () => {
      const gradeId = examGradeSelect.value;

      const selectedGrade = allGrades.find(
          g => String(g.id) === String(gradeId)
      );

      if (!selectedGrade) {
        populateSelect(examClazzSelect, [], "选择班级");
        return;
      }

      const filteredClazz = allClazzes.filter(
          c => c.grade === selectedGrade.name
      );

      populateSelect(examClazzSelect, filteredClazz, "选择班级");
    }
  );
  }
}

 */

async function loadAllBaseData() {
  allGrades = await fetchJSON("/system/list?method=listAllGrade") || [];
  allCourses = await fetchJSON("/system/list?method=listAllCourse") || [];
  allClazzes = await fetchJSON("/system/list?method=listAllClazz") || [];

  // 新增：把教师和学生也预先拉下来以便填入修改下拉
  allTeachers = await fetchJSON("/system/list?method=listAllTeacher") || [];
  allStudents = await fetchJSON("/system/list?method=listAllStudent") || [];

  // 填充考试管理下拉框
  populateSelect(document.getElementById("examGradeSelect"), allGrades, "选择年级");
  populateSelect(document.getElementById("examCourseSelect"), allCourses, "选择课程");
  populateSelect(document.getElementById("examClazzSelect"), [], "选择班级");

  // 填充新增表单处的年级下拉（班级新增）
  populateSelect(document.getElementById("clazzGradeSelect"), allGrades, "选择年级");

  // 填充新增学生/教师处用到的年级（学生新增）
  populateSelect(document.getElementById("studentGradeSelect"), allGrades, "选择年级");

  // 填充修改用的下拉（教师/学生）
  populateSelect(document.getElementById("updateTeacherSelect"), allTeachers, "选择教师");
  populateSelect(document.getElementById("updateStudentSelect"), allStudents, "选择学生");

  // console.debug 调试（可选）
  // console.log({ allGrades, allClazzes, allTeachers, allStudents });

  // 绑定考试年级→班级联动（保持你现有逻辑）
  const examGradeSelect = document.getElementById("examGradeSelect");
  const examClazzSelect = document.getElementById("examClazzSelect");

  if (examGradeSelect && examClazzSelect) {
    examGradeSelect.addEventListener("change", () => {
      const gradeId = examGradeSelect.value;
      const selectedGrade = allGrades.find(g => String(g.id) === String(gradeId));
      if (!selectedGrade) {
        populateSelect(examClazzSelect, [], "选择班级");
        return;
      }
      const filteredClazz = allClazzes.filter(c => c.grade === selectedGrade.name);
      populateSelect(examClazzSelect, filteredClazz, "选择班级");
    });
  }
}

async function putJSON(url, data) {
  const res = await fetch(url, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  const text = await res.text();
  try {
    const json = text ? JSON.parse(text) : null;
    if (!res.ok) throw new Error(json?.message || text || `Request failed ${res.status}`);
    return json;
  } catch (err) {
    // 当返回的是非 JSON 文本
    if (!res.ok) throw new Error(text || `Request failed ${res.status}`);
    return null;
  }
}

function bindUpdateForm(formId, statusId, handler) {
  const form = document.getElementById(formId);
  const statusEl = document.getElementById(statusId);
  if (!form) return;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    setStatus(statusEl, "");
    try {
      await handler(form);
      setStatus(statusEl, "操作成功", "success");
      // 更新本地缓存并刷新列表（可见变更）
      await loadAllBaseData();
      await loadBasicLists();
      form.reset();
    } catch (err) {
      setStatus(statusEl, err.message || "操作失败");
    }
  });
}

function bindUpdateFormsAndSelects() {
  // 当选择某个教师时，把数据填到表单
  const teacherSelect = document.getElementById("updateTeacherSelect");
  if (teacherSelect) {
    teacherSelect.addEventListener("change", () => {
      const id = teacherSelect.value;
      const t = allTeachers.find(x => String(x.id) === String(id));
      if (!t) {
        // 清空表单
        document.getElementById("updateTeacherId").value = "";
        document.getElementById("updateTeacherNumber").value = "";
        document.getElementById("updateTeacherName").value = "";
        document.getElementById("updateTeacherSex").value = "";
        document.getElementById("updateTeacherPhone").value = "";
        document.getElementById("updateTeacherQq").value = "";
        return;
      }
      document.getElementById("updateTeacherId").value = t.id ?? "";
      document.getElementById("updateTeacherNumber").value = t.number ?? "";
      document.getElementById("updateTeacherName").value = t.name ?? "";
      document.getElementById("updateTeacherSex").value = t.sex ?? "";
      document.getElementById("updateTeacherPhone").value = t.phone ?? "";
      document.getElementById("updateTeacherQq").value = t.qq ?? "";
    });
  }

  // 学生选择填表
  const studentSelect = document.getElementById("updateStudentSelect");
  if (studentSelect) {
    studentSelect.addEventListener("change", () => {
      const id = studentSelect.value;
      const s = allStudents.find(x => String(x.id) === String(id));
      if (!s) {
        document.getElementById("updateStudentId").value = "";
        document.getElementById("updateStudentNumber").value = "";
        document.getElementById("updateStudentName").value = "";
        document.getElementById("updateStudentSex").value = "";
        document.getElementById("updateStudentPhone").value = "";
        document.getElementById("updateStudentQq").value = "";
        return;
      }
      document.getElementById("updateStudentId").value = s.id ?? "";
      document.getElementById("updateStudentNumber").value = s.number ?? "";
      document.getElementById("updateStudentName").value = s.name ?? "";
      document.getElementById("updateStudentSex").value = s.sex ?? "";
      document.getElementById("updateStudentPhone").value = s.phone ?? "";
      document.getElementById("updateStudentQq").value = s.qq ?? "";
    });
  }

  // 绑定表单提交（PUT）
  bindUpdateForm("updateTeacherForm", "updateTeacherStatus", (form) =>
      putJSON("/system/updateTeacher", {
        id: Number(form.id.value) || null,
        number: form.number.value.trim(),
        name: form.name.value.trim(),
        sex: form.sex.value.trim(),
        phone: form.phone.value.trim(),
        qq: form.qq.value.trim(),
      })
  );

  bindUpdateForm("updateStudentForm", "updateStudentStatus", (form) =>
      putJSON("/system/updateStudent", {
        id: Number(form.id.value) || null,
        number: form.number.value.trim(),
        name: form.name.value.trim(),
        sex: form.sex.value.trim(),
        phone: form.phone.value.trim(),
        qq: form.qq.value.trim(),
      })
  );
}


async function loadList(type) {
  const methodMap = {
    grade: "listAllGrade",
    clazz: "listAllClazz",
    course: "listAllCourse",
    teacher: "listAllTeacher",
    student: "listAllStudent",
    exam: "listAllExam",
  };
  const targetEl = document.getElementById(`${type}List`);
  if (!targetEl) return;
  try {
    const list = await fetchJSON(`/system/list?method=${methodMap[type]}`);
    const columns = {
      grade: [{ title: "ID", dataIndex: "id" }, { title: "名称", dataIndex: "name" }],
      clazz: [
        { title: "ID", dataIndex: "id" },
        { title: "班级", dataIndex: "name" },
        { title: "年级ID", dataIndex: "gradeId" },
      ],
      course: [
        { title: "ID", dataIndex: "id" },
        { title: "课程", dataIndex: "name" },
      ],
      teacher: [
        { title: "ID", dataIndex: "id" },
        { title: "工号", dataIndex: "number" },
        { title: "姓名", dataIndex: "name" },
        { title: "电话", dataIndex: "phone" },
      ],
      student: [
        { title: "ID", dataIndex: "id" },
        { title: "学号", dataIndex: "number" },
        { title: "姓名", dataIndex: "name" },
        { title: "班级", dataIndex: "clazzId" },
        { title: "年级", dataIndex: "gradeId" },
      ],
      exam: [
        { title: "ID", dataIndex: "id" },
        { title: "考试", dataIndex: "name" },
        { title: "日期", dataIndex: "time" },
        { title: "类型", dataIndex: "type" },
        { title: "年级ID", dataIndex: "gradeId" },
        { title: "班级ID", dataIndex: "clazzId" },
        { title: "课程ID", dataIndex: "courseId" },
      ],
    }[type];
    const normalized =
      list?.map((item) =>
        type === "exam"
          ? { ...item, time: formatDate(item.time) }
          : item
      ) || [];
    renderTable(normalized, columns, targetEl);
  } catch (err) {
    targetEl.innerHTML = `<p class="error">${err.message}</p>`;
  }
}

function bindForms() {
  bindSimpleForm("addGradeForm", "addGradeStatus", (form) =>
    postForm("/system/addGrade", { name: form.name.value.trim() })
  );

  bindSimpleForm("addCourseForm", "addCourseStatus", (form) =>
    postForm("/system/addCourse", { name: form.name.value.trim() })
  );

  bindSimpleForm("addClazzForm", "addClazzStatus", (form) =>
    postForm("/system/addClazz", {
      name: form.name.value.trim(),
      gradeId: form.gradeId.value.trim(),
    })
  );

  bindSimpleForm("bindCourseGradeForm", "bindCourseGradeStatus", (form) =>
    postForm("/system/addCourseByGrade", {
      gradeId: form.gradeId.value.trim(),
      courseId: form.courseId.value.trim(),
    })
  );

  bindSimpleForm("addTeacherForm", "addTeacherStatus", (form) =>
    postForm("/system/addTeacher", {
      number: form.number.value.trim(),
      name: form.name.value.trim(),
      sex: form.sex.value.trim(),
      phone: form.phone.value.trim(),
      qq: form.qq.value.trim(),
    })
  );

  bindSimpleForm("addStudentForm", "addStudentStatus", (form) =>
    postForm("/system/addStudent", {
      number: form.number.value.trim(),
      name: form.name.value.trim(),
      sex: form.sex.value.trim(),
      phone: form.phone.value.trim(),
      qq: form.qq.value.trim(),
      clazzId: form.clazzId.value.trim(),
      gradeId: form.gradeId.value.trim(),
    })
  );

  bindSimpleForm("addExamForm", "addExamStatus", (form) =>
    postForm("/system/addExam", {
      name: form.name.value.trim(),
      time: form.time.value.trim(),
      remark: form.remark.value.trim(),
      type: form.type.value,
      gradeId: form.gradeId.value.trim(),
      clazzId: form.clazzId.value.trim(),
      courseId: form.courseId.value.trim(),
    })
  );
}

function bindSimpleForm(formId, statusId, handler) {
  const form = document.getElementById(formId);
  const statusEl = document.getElementById(statusId);
  if (!form) return;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    setStatus(statusEl, "");
    try {
      await handler(form);
      setStatus(statusEl, "操作成功", "success");
      await loadBasicLists();
      form.reset();
    } catch (err) {
      setStatus(statusEl, err.message || "操作失败");
    }
  });
}

