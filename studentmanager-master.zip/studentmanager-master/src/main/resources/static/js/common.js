const storageKey = "ssmsUser";

export function saveUser(user) {
  localStorage.setItem(storageKey, JSON.stringify(user));
}

export function getUser() {
  const raw = localStorage.getItem(storageKey);
  try {
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    return null;
  }
}

export function clearUser() {
  localStorage.removeItem(storageKey);
}

export function ensureUser(expectedTypes) {
  const user = getUser();
  if (!user || (expectedTypes && !expectedTypes.includes(user.type))) {
    window.location.href = "login.html";
    return null;
  }
  return user;
}

export async function fetchJSON(url, options = {}) {
  const resp = await fetch(url, options);
  const data = await resp.json();
  if (!data || data.code !== "200") {
    const msg = data ? data.msg : "请求失败";
    throw new Error(msg);
  }
  return data.data;
}

export async function postForm(url, payload) {
  const body = new URLSearchParams(payload);
  return fetchJSON(url, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body,
  });
}

export function renderTable(rows, columns, target) {
  if (!rows || rows.length === 0) {
    target.innerHTML = '<p class="muted">暂无数据</p>';
    return;
  }
  const thead = columns
    .map((c) => `<th>${c.title}</th>`)
    .join("");
  const tbody = rows
    .map((row) => {
      const tds = columns
        .map((c) => `<td>${row[c.dataIndex] ?? ""}</td>`)
        .join("");
      return `<tr>${tds}</tr>`;
    })
    .join("");
  target.innerHTML = `<table class="table"><thead><tr>${thead}</tr></thead><tbody>${tbody}</tbody></table>`;
}

export function renderList(items, target, formatter) {
  if (!items || items.length === 0) {
    target.innerHTML = '<p class="muted">暂无数据</p>';
    return;
  }
  const html = items
    .map((item) => `<li>${formatter(item)}</li>`)
    .join("");
  target.innerHTML = `<ul class="list">${html}</ul>`;
}


/*export function formatDate(val) {
  if (!val) return "";
  try {
    const d = new Date(val);
    return d.toISOString().slice(0, 10);
  } catch (e) {
    return val;
  }
}

 */

export function formatDate(val) {
  if (!val) return "";

  const d = new Date(val); // 浏览器自动处理时区
  if (isNaN(d.getTime())) return "";

  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");

  return `${y}-${m}-${day}`;
}

export function setStatus(el, message, type = "error") {
  el.textContent = message || "";
  el.className = type === "error" ? "error" : "success";
}

export function bindLogout(buttonId) {
  const btn = document.getElementById(buttonId);
  if (btn) {
    btn.addEventListener("click", () => {
      clearUser();
      window.location.href = "login.html";
    });
  }
}

