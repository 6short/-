import {
  ensureUser,
  fetchJSON,
  postForm,
  renderTable,
  renderList,
  formatDate,
  setStatus,
  bindLogout,
} from "./common.js";

const user = ensureUser([2]);
if (user) {
  init();
}

async function init() {
  bindLogout("logoutBtn");
  document.getElementById("welcomeName").textContent = user.name;
  document.getElementById("welcomeAccount").textContent = user.account;
  await loadProfileAndData();
  await loadDropdowns();
  bindTrendForm();
  bindSubjectBarForm();
  bindPasswordForm();
}

async function loadProfileAndData() {
  const profileBox = document.getElementById("profileBox");
  const examBox = document.getElementById("examBox");
  try {
    const profile = await fetchJSON(
      `/student/listStudentByNumber?number=${encodeURIComponent(user.account)}`
    );
    if (!profile) throw new Error("未找到学生信息");
    profileBox.innerHTML = `
      <div class="grid grid-2">
        <div><div class="section-title">姓名</div><div>${profile.name}</div></div>
        <div><div class="section-title">学号</div><div>${profile.number}</div></div>
        <div><div class="section-title">年级</div><div>${profile.gradeId}</div></div>
        <div><div class="section-title">班级</div><div>${profile.clazzId}</div></div>
        <div><div class="section-title">电话</div><div>${profile.phone || "-"}</div></div>
        <div><div class="section-title">QQ</div><div>${profile.qq || "-"}</div></div>
      </div>
    `;
    document.getElementById("studentId").value = profile.id;
    await loadExams(profile.id, examBox);
    await loadClassmates(profile.id);
  } catch (err) {
    profileBox.innerHTML = `<p class="error">${err.message}</p>`;
  }
}

async function loadExams(studentId, target) {

  const rows = await fetchJSON(
    `/student/listExamByStudent?studentId=${studentId}`
  );

  const normalized =
      rows?.map((item) => {
        console.log("raw time:", item.time);
        console.log("formatted:", formatDate(item.time));

        return {
          name: item.name,
          time: formatDate(item.time),
          type: item.type === 1 ? "统考" : "班级",
          grade: item.grade,
          clazz: item.clazz || "-",
          course: item.course,
          score: item.score || "-",
        };
      }) || [];


  renderTable(
    normalized,
    [
      { title: "考试", dataIndex: "name" },
      { title: "日期", dataIndex: "time" },
      { title: "类型", dataIndex: "type" },
      { title: "年级", dataIndex: "grade" },
      { title: "班级", dataIndex: "clazz" },
      { title: "科目", dataIndex: "course" },
      { title: "成绩", dataIndex: "score" },
    ],
    target
  );
}

async function loadClassmates(studentId) {
  const container = document.getElementById("classmateBox");
  const list = await fetchJSON(
    `/student/listClazzByStudent?studentId=${studentId}`
  );
  renderList(
    list || [],
    container,
    (item) => `${item.name} (${item.number}) - ${item.clazzId} / ${item.gradeId}`
  );
}

async function loadDropdowns() {
  const trendCourseSelect = document.getElementById("trendCourse");
  const subjectGradeSelect = document.getElementById("subjectGradeId");
  const subjectCourseSelect = document.getElementById("subjectCourse");
  if (!trendCourseSelect || !subjectGradeSelect || !subjectCourseSelect) return;
  trendCourseSelect.innerHTML = `<option value="">加载课程...</option>`;
  subjectGradeSelect.innerHTML = `<option value="">加载年级...</option>`;
  subjectCourseSelect.innerHTML = `<option value="">请选择年级</option>`;
  try {
    const [grades, courses] = await Promise.all([
      fetchJSON("/system/list?method=listAllGrade"),
      fetchJSON("/system/list?method=listAllCourse"),
    ]);
    populateSelect(
      trendCourseSelect,
      courses,
      "全部课程",
      "id",
      "name"
    );
    populateSelect(
      subjectGradeSelect,
      grades,
      "选择年级",
      "id",
      "name"
    );
    populateSelect(
      subjectCourseSelect,
      courses,
      "全部课程",
      "id",
      "name"
    );
    subjectGradeSelect.addEventListener("change", (e) =>
      refreshGradeCourses(e.target.value)
    );
  } catch (err) {
    const target = document.getElementById("trendStatus");
    setStatus(target, err.message || "加载课程/年级失败");
  }
}

async function refreshGradeCourses(gradeId) {
  const subjectCourseSelect = document.getElementById("subjectCourse");
  const subjectStatus = document.getElementById("subjectStatus");
  if (!subjectCourseSelect) return;
  if (!gradeId) {
    populateSelect(subjectCourseSelect, [], "全部课程");
    return;
  }
  subjectCourseSelect.innerHTML = `<option value="">加载课程...</option>`;
  try {
    const list = await fetchJSON(
      `/system/list?method=listCourseByGradeId&gradeId=${gradeId}`
    );
    populateSelect(subjectCourseSelect, list, "全部课程", "courseId", "course");
    setStatus(subjectStatus, "");
  } catch (err) {
    setStatus(subjectStatus, err.message || "加载课程失败");
  }
}

function populateSelect(selectEl, list, placeholder, valueKey = "id", labelKey = "name") {
  const options = [`<option value="">${placeholder || "请选择"}</option>`];
  (list || []).forEach((item) => {
    options.push(
      `<option value="${item?.[valueKey] ?? ""}">${item?.[labelKey] ?? ""}</option>`
    );
  });
  selectEl.innerHTML = options.join("");
}

/*
function bindTrendForm() {
  const form = document.getElementById("trendForm");
  const statusEl = document.getElementById("trendStatus");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    setStatus(statusEl, "");
    const studentId = document.getElementById("studentId").value;
    const courseId = document.getElementById("trendCourse").value;
    const url = new URL(
      `/analysis/student/examTrend`,
      window.location.origin
    );
    url.searchParams.set("studentId", studentId);
    if (courseId) url.searchParams.set("courseId", courseId);
    try {
      const list = await fetchJSON(url.toString());
      renderTable(
        (list || []).map((x) => ({
          examName: x.examName,
          time: formatDate(x.time),
          courseName: x.courseName,
          score: x.score,
        })),
        [
          { title: "考试", dataIndex: "examName" },
          { title: "日期", dataIndex: "time" },
          { title: "科目", dataIndex: "courseName" },
          { title: "成绩", dataIndex: "score" },
        ],
        document.getElementById("trendResult")
      );
      setStatus(statusEl, "加载成功", "success");
    } catch (err) {
      setStatus(statusEl, err.message);
    }
  });
}

 */

function bindTrendForm() {
  const form = document.getElementById("trendForm");
  const statusEl = document.getElementById("trendStatus");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    setStatus(statusEl, "");
    const studentId = document.getElementById("studentId").value;
    const courseId = document.getElementById("trendCourse").value;
    const url = new URL(`/analysis/student/examTrend`, window.location.origin);
    url.searchParams.set("studentId", studentId);
    if (courseId) url.searchParams.set("courseId", courseId);

    try {
      const list = await fetchJSON(url.toString());

      // 先渲染表格
      renderTable(
          (list || []).map((x) => ({
            examName: x.examName,
            time: formatDate(x.time),
            courseName: x.courseName,
            score: x.score,
          })),
          [
            { title: "考试", dataIndex: "examName" },
            { title: "日期", dataIndex: "time" },
            { title: "科目", dataIndex: "courseName" },
            { title: "成绩", dataIndex: "score" },
          ],
          document.getElementById("trendResult")
      );

      // 🔹 绘制折线图
      const chartDom = document.getElementById("trendChart");
      const myChart = echarts.init(chartDom);

      // 按考试日期排序
      const sorted = (list || []).sort((a, b) => new Date(a.time) - new Date(b.time));

      const option = {
        title: { text: '成绩趋势' },
        tooltip: { trigger: 'axis' },
        xAxis: {
          type: 'category',
          data: sorted.map(x => formatDate(x.time)), // 日期
          name: '考试日期'
        },
        yAxis: {
          type: 'value',
          name: '成绩',
          min: 0,
          max: 100
        },
        series: [{
          name: courseId ? sorted[0]?.courseName : '成绩',
          type: 'line',
          data: sorted.map(x => x.score),
          smooth: true,
          label: { show: true, position: 'top' }
        }]
      };

      myChart.setOption(option);

      setStatus(statusEl, "加载成功", "success");
    } catch (err) {
      setStatus(statusEl, err.message);
    }
  });
}

/*
function bindSubjectBarForm() {
  const form = document.getElementById("subjectForm");
  const statusEl = document.getElementById("subjectStatus");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    setStatus(statusEl, "");
    const studentId = document.getElementById("studentId").value;
    const gradeId = document.getElementById("subjectGradeId").value;
    const examDate = document.getElementById("examDate").value.trim();
    const type = document.getElementById("examType").value;
    const courseId = document.getElementById("subjectCourse").value;
    if (!gradeId || !examDate) {
      setStatus(statusEl, "请选择年级并输入日期");
      return;
    }
    const url = new URL(
      `/analysis/student/subjectBar`,
      window.location.origin
    );
    url.searchParams.set("studentId", studentId);
    url.searchParams.set("gradeId", gradeId);
    url.searchParams.set("examDate", examDate);
    url.searchParams.set("type", type);
    if (courseId) url.searchParams.set("courseId", courseId);
    try {
      const list = await fetchJSON(url.toString());
      renderTable(
        (list || []).map((x) => ({
          examName: x.examName,
          courseName: x.courseName,
          score: x.score,
        })),
        [
          { title: "考试", dataIndex: "examName" },
          { title: "科目", dataIndex: "courseName" },
          { title: "成绩", dataIndex: "score" },
        ],
        document.getElementById("subjectResult")
      );
      setStatus(statusEl, "加载成功", "success");
    } catch (err) {
      setStatus(statusEl, err.message);
    }
  });
}

 */

function bindSubjectBarForm() {
  const form = document.getElementById("subjectForm");
  const statusEl = document.getElementById("subjectStatus");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    setStatus(statusEl, "");

    const studentId = document.getElementById("studentId").value;
    const gradeId = document.getElementById("subjectGradeId").value;
    const examDate = document.getElementById("examDate").value.trim();
    const type = document.getElementById("examType").value;
    const courseId = document.getElementById("subjectCourse").value;

    if (!gradeId || !examDate) {
      setStatus(statusEl, "请选择年级并输入日期");
      return;
    }

    const url = new URL(`/analysis/student/subjectBar`, window.location.origin);
    url.searchParams.set("studentId", studentId);
    url.searchParams.set("gradeId", gradeId);
    url.searchParams.set("examDate", examDate);
    url.searchParams.set("type", type);
    if (courseId) url.searchParams.set("courseId", courseId);

    try {
      const list = await fetchJSON(url.toString());

      // 渲染表格
      renderTable(
          (list || []).map((x) => ({
            examName: x.examName,
            courseName: x.courseName,
            score: x.score,
          })),
          [
            { title: "考试", dataIndex: "examName" },
            { title: "科目", dataIndex: "courseName" },
            { title: "成绩", dataIndex: "score" },
          ],
          document.getElementById("subjectResult")
      );

      // 绘制饼状图
      const chartDom = document.getElementById("subjectChart");
      const myChart = echarts.init(chartDom);

      if (!list || list.length === 0) {
        myChart.clear();
        setStatus(statusEl, "无数据", "error");
        return;
      }

      const pieData = (list || []).map((x) => ({
        name: x.courseName,
        value: Number(x.score) || 0
      }));

      const option = {
        title: { text: '同日成绩占比', left: 'center' },
        tooltip: { trigger: 'item', formatter: '{b}: {c} 分 ({d}%)' },
        legend: { orient: 'vertical', left: 'left', data: pieData.map(d => d.name) },
        series: [
          {
            name: '成绩',
            type: 'pie',
            radius: '50%',
            data: pieData,
            emphasis: {
              itemStyle: { shadowBlur: 10, shadowOffsetX: 0, shadowColor: 'rgba(0,0,0,0.5)' }
            },
            label: { formatter: '{b}: {c}' }
          }
        ]
      };

      myChart.setOption(option);

      setStatus(statusEl, "加载成功", "success");
    } catch (err) {
      setStatus(statusEl, err.message || "加载失败");
    }
  });
}



function bindPasswordForm() {
  const form = document.getElementById("passwordForm");
  const statusEl = document.getElementById("passwordStatus");
  if (!form) return;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    setStatus(statusEl, "");
    const oldPassword = document.getElementById("oldPassword").value.trim();
    const newPassword = document.getElementById("newPassword").value.trim();
    const confirmPassword = document
      .getElementById("confirmPassword")
      .value.trim();
    if (!oldPassword || !newPassword) {
      setStatus(statusEl, "请输入原密码和新密码");
      return;
    }
    if (newPassword !== confirmPassword) {
      setStatus(statusEl, "两次输入的新密码不一致");
      return;
    }
    try {
      await postForm("/system/updatePasswordByAccount", {
        account: user.account,
        oldPassword,
        newPassword,
      });
      form.reset();
      setStatus(statusEl, "密码修改成功", "success");
    } catch (err) {
      setStatus(statusEl, err.message || "修改失败");
    }
  });
}

