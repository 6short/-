import { setStatus } from "./common.js";

const form = document.getElementById("resetForm");
const typeSelect = document.getElementById("type");

const idBox = document.getElementById("idBox");
const idLabel = document.getElementById("idLabel");
import { setStatus } from "./common.js";

const form = document.getElementById("resetForm");
const typeSelect = document.getElementById("type");

const idBox = document.getElementById("idBox");
const idLabel = document.getElementById("idLabel");
const userIdInput = document.getElementById("userId");

const accountBox = document.getElementById("accountBox");
const accountInput = document.getElementById("account");

const statusEl = document.getElementById("status");


typeSelect.addEventListener("change", () => {
    const type = typeSelect.value;
    idBox.style.display = "none";
    accountBox.style.display = "none";

    if (type === "student") {
        idLabel.textContent = "学生ID *";
        idBox.style.display = "block";
    } else if (type === "teacher") {
        idLabel.textContent = "教师ID *";
        idBox.style.display = "block";
    } else if (type === "admin") {
        accountBox.style.display = "block";
    }
});

form.addEventListener("submit", async (e) => {
    e.preventDefault();
    setStatus(statusEl, "");

    const type = typeSelect.value;
    const oldPassword = document.getElementById("oldPassword").value.trim();
    const newPassword = document.getElementById("newPassword").value.trim();
    const confirmPassword = document.getElementById("confirmPassword").value.trim();

    if (!type || !oldPassword || !newPassword) {
        setStatus(statusEl, "请填写完整信息");
        return;
    }

    if (newPassword !== confirmPassword) {
        setStatus(statusEl, "两次输入的新密码不一致");
        return;
    }

    let url = "";
    let params = {};

    if (type === "student") {
        const studentId = userIdInput.value.trim();
        if (!studentId) return setStatus(statusEl, "请输入学生ID");

        url = "/updatePasswordByStudent";
        params = { studentId, oldPassword, newPassword };
    }

    if (type === "teacher") {
        const teacherId = userIdInput.value.trim();
        if (!teacherId) return setStatus(statusEl, "请输入教师ID");

        url = "/updatePasswordByTeacher";
        params = { teacherId, oldPassword, newPassword };
    }

    if (type === "admin") {
        const account = accountInput.value.trim();
        if (!account) return setStatus(statusEl, "请输入账号");

        url = "/updatePasswordByAccount";
        params = { account, oldPassword, newPassword };
    }

    try {
        const res = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams(params)
        });

        const data = await res.json();
        if (data.code !== "200") {
            setStatus(statusEl, data.msg || "修改失败");
            return;
        }

        alert("密码修改成功，请重新登录");
        window.location.href = "login.html";
    } catch (e) {
        setStatus(statusEl, "请求失败");
    }
});

const userIdInput = document.getElementById("userId");

const accountBox = document.getElementById("accountBox");
const accountInput = document.getElementById("account");

const statusEl = document.getElementById("status");


typeSelect.addEventListener("change", () => {
    const type = typeSelect.value;
    idBox.style.display = "none";
    accountBox.style.display = "none";

    if (type === "student") {
        idLabel.textContent = "学生ID *";
        idBox.style.display = "block";
    } else if (type === "teacher") {
        idLabel.textContent = "教师ID *";
        idBox.style.display = "block";
    } else if (type === "admin") {
        accountBox.style.display = "block";
    }
});

form.addEventListener("submit", async (e) => {
    e.preventDefault();
    setStatus(statusEl, "");

    const type = typeSelect.value;
    const oldPassword = document.getElementById("oldPassword").value.trim();
    const newPassword = document.getElementById("newPassword").value.trim();
    const confirmPassword = document.getElementById("confirmPassword").value.trim();

    if (!type || !oldPassword || !newPassword) {
        setStatus(statusEl, "请填写完整信息");
        return;
    }

    if (newPassword !== confirmPassword) {
        setStatus(statusEl, "两次输入的新密码不一致");
        return;
    }

    let url = "";
    let params = {};

    if (type === "student") {
        const studentId = userIdInput.value.trim();
        if (!studentId) return setStatus(statusEl, "请输入学生ID");

        url = "/updatePasswordByStudent";
        params = { studentId, oldPassword, newPassword };
    }

    if (type === "teacher") {
        const teacherId = userIdInput.value.trim();
        if (!teacherId) return setStatus(statusEl, "请输入教师ID");

        url = "/updatePasswordByTeacher";
        params = { teacherId, oldPassword, newPassword };
    }

    if (type === "admin") {
        const account = accountInput.value.trim();
        if (!account) return setStatus(statusEl, "请输入账号");

        url = "/updatePasswordByAccount";
        params = { account, oldPassword, newPassword };
    }

    try {
        const res = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams(params)
        });

        const data = await res.json();
        if (data.code !== "200") {
            setStatus(statusEl, data.msg || "修改失败");
            return;
        }

        alert("密码修改成功，请重新登录");
        window.location.href = "login.html";
    } catch (e) {
        setStatus(statusEl, "请求失败");
    }
});
