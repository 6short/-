/*import { setStatus } from "./common.js";

const form = document.getElementById("registerForm");
const statusEl = document.getElementById("registerStatus");

form.addEventListener("submit", async (e) => {
    e.preventDefault();
    setStatus(statusEl, "");

    const account = document.getElementById("account").value.trim();
    const password = document.getElementById("password").value.trim();
    const name = document.getElementById("name").value.trim();
    const type = document.getElementById("type").value;

    if (!account || !password || !name || !type) {
        setStatus(statusEl, "请填写所有必填项");
        return;
    }

    const params = new URLSearchParams();
    params.append("account", account);
    params.append("password", password);
    params.append("name", name);
    params.append("type", type);

    // 可选参数：有值才传
    const clazzId = document.getElementById("clazzId").value;
    const gradeId = document.getElementById("gradeId").value;
    const sex = document.getElementById("sex").value;
    const phone = document.getElementById("phone").value.trim();
    const qq = document.getElementById("qq").value.trim();

    if (clazzId) params.append("clazzId", clazzId);
    if (gradeId) params.append("gradeId", gradeId);
    if (sex) params.append("sex", sex);
    if (phone) params.append("phone", phone);
    if (qq) params.append("qq", qq);

    try {
        const res = await fetch("/register", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
            },
            body: params.toString(),
        });

        const data = await res.json();

        if (!data || data.code !== "200") {
            setStatus(statusEl, data ? data.msg : "注册失败");
            return;
        }

        alert("注册成功，请登录");
        window.location.href = "login.html";
    } catch (err) {
        setStatus(statusEl, err.message || "注册失败");
    }
});


 */

import { setStatus } from "./common.js";

const form = document.getElementById("registerForm");
const statusEl = document.getElementById("registerStatus");

const gradeSelect = document.getElementById("gradeId");
const clazzSelect = document.getElementById("clazzId");

/* ========== 1. 页面加载 → 加载年级 ========== */
window.addEventListener("DOMContentLoaded", loadGrades);

async function loadGrades() {
    try {
        const res = await fetch("/system/list?method=listAllGrade");
        const data = await res.json();
        if (data.code !== "200") return;

        data.data.forEach(g => {
            const opt = document.createElement("option");
            opt.value = g.id;
            opt.textContent = g.name;
            gradeSelect.appendChild(opt);
        });
    } catch (e) {
        console.error("加载年级失败", e);
    }
}

/* ========== 2. 选择年级 → 加载班级 ========== */
gradeSelect.addEventListener("change", async () => {
    const gradeId = gradeSelect.value;
    clazzSelect.innerHTML = '<option value="">请选择班级</option>';
    clazzSelect.disabled = true;

    if (!gradeId) return;

    try {
        const res = await fetch(`/system/list?method=listClazzByGradeId&gradeId=${gradeId}`);
        const data = await res.json();
        if (data.code !== "200") return;

        data.data.forEach(c => {
            const opt = document.createElement("option");
            opt.value = c.id;
            opt.textContent = c.name;
            clazzSelect.appendChild(opt);
        });

        clazzSelect.disabled = false;
    } catch (e) {
        console.error("加载班级失败", e);
    }
});

/* ========== 3. 提交注册 ========== */
form.addEventListener("submit", async (e) => {
    e.preventDefault();
    setStatus(statusEl, "");

    const account = document.getElementById("account").value.trim();
    const password = document.getElementById("password").value.trim();
    const name = document.getElementById("name").value.trim();
    const type = document.getElementById("type").value;
    const gradeId = gradeSelect.value;
    const clazzId = clazzSelect.value;

    if (!account || !password || !name || !type || !gradeId || !clazzId) {
        setStatus(statusEl, "请完整填写注册信息");
        return;
    }

    const params = new URLSearchParams({
        account,
        password,
        name,
        type,
        gradeId,
        clazzId
    });

    const sex = document.getElementById("sex").value;
    const phone = document.getElementById("phone").value.trim();
    const qq = document.getElementById("qq").value.trim();

    if (sex) params.append("sex", sex);
    if (phone) params.append("phone", phone);
    if (qq) params.append("qq", qq);

    try {
        const res = await fetch("/register", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: params.toString(),
        });

        const data = await res.json();
        if (data.code !== "200") {
            setStatus(statusEl, data.msg || "注册失败");
            return;
        }

        alert("注册成功，请登录");
        window.location.href = "login.html";
    } catch (err) {
        setStatus(statusEl, "注册失败");
    }
});
